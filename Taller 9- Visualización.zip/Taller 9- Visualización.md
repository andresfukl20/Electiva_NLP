<img src='https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ-VfNtOyJbsaxu43Kztf_cv1mgBG6ZIQZEVw&usqp=CAU'>


# Procesamiento de Lenguage Natural

## Taller #9: Visualización



```python

import pandas as pd 

import numpy as np

from wordcloud import WordCloud
from wordcloud import ImageColorGenerator

from nltk.corpus import stopwords
stopwords = stopwords.words('spanish')

import matplotlib.pyplot as plt
import PIL.Image
from IPython.display import display

```


```python
# Cargar datos
path = 'D:/Users/User/Imágenes/Especialización Analítica Estratégica de Datos/Semestre II/Electiva NLP/Clase 9/reviews_vidjew_es.csv'
data = pd.read_csv(path)
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>review_id</th>
      <th>product_id</th>
      <th>reviewer_id</th>
      <th>stars</th>
      <th>review_body</th>
      <th>review_title</th>
      <th>language</th>
      <th>product_category</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>es_0825565</td>
      <td>product_es_0370490</td>
      <td>reviewer_es_0174781</td>
      <td>3</td>
      <td>Buen. Buena calidad, y buena presentación.</td>
      <td>Contenta</td>
      <td>es</td>
      <td>jewelry</td>
    </tr>
    <tr>
      <th>1</th>
      <td>es_0227934</td>
      <td>product_es_0354224</td>
      <td>reviewer_es_0411613</td>
      <td>3</td>
      <td>Un producto a perfecto, para salir de casa con...</td>
      <td>Versatilidad</td>
      <td>es</td>
      <td>video_games</td>
    </tr>
    <tr>
      <th>2</th>
      <td>es_0468601</td>
      <td>product_es_0665460</td>
      <td>reviewer_es_0348315</td>
      <td>1</td>
      <td>No funciona con Nintendo Switch. No hay forma ...</td>
      <td>Decepción absoluta</td>
      <td>es</td>
      <td>video_games</td>
    </tr>
    <tr>
      <th>3</th>
      <td>es_0814494</td>
      <td>product_es_0692692</td>
      <td>reviewer_es_0951508</td>
      <td>5</td>
      <td>Recomendado, los utilizo para pc y no me dan n...</td>
      <td>Auriculares Pecham ps4</td>
      <td>es</td>
      <td>video_games</td>
    </tr>
    <tr>
      <th>4</th>
      <td>es_0206329</td>
      <td>product_es_0728826</td>
      <td>reviewer_es_0493255</td>
      <td>4</td>
      <td>El cable funciona bien podria ser un poco mas ...</td>
      <td>Perfecto</td>
      <td>es</td>
      <td>video_games</td>
    </tr>
  </tbody>
</table>
</div>




```python
palabras = data.review_body.str.cat(sep=" ")
wordcloud = WordCloud().generate(palabras)

plt.imshow(wordcloud)
plt.show()
```


![png](output_3_0.png)



```python
palabras = data.review_body.str.cat(sep=' ')

wordcloud = WordCloud(width=800, height=400,
                     max_font_size=150, max_words=250,
                     background_color='white', colormap='gist_heat',
                     stopwords=stopwords).generate(palabras) # https://matplotlib.org/3.1.0/tutorials/colors/colormaps.html

plt.figure(figsize=(10,8))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.tight_layout(pad=0)
plt.show()
```


![png](output_4_0.png)



```python
videoju = PIL.Image.open("D:/Users/User/Imágenes/Especialización Analítica Estratégica de Datos/Semestre II/Electiva NLP/Clase 11/mario.png")
display(videoju)
```


![png](output_5_0.png)



```python
mask = np.array(videoju)
mask
```




    array([[[255, 255, 255],
            [255, 255, 255],
            [255, 255, 255],
            ...,
            [212, 212, 213],
            [212, 212, 213],
            [255, 255, 255]],
    
           [[255, 255, 255],
            [255, 255, 255],
            [255, 255, 255],
            ...,
            [212, 212, 213],
            [212, 212, 213],
            [255, 255, 255]],
    
           [[255, 255, 255],
            [255, 255, 255],
            [255, 255, 255],
            ...,
            [212, 212, 213],
            [212, 212, 213],
            [255, 255, 255]],
    
           ...,
    
           [[212, 212, 213],
            [212, 212, 213],
            [212, 212, 213],
            ...,
            [255, 255, 255],
            [255, 255, 255],
            [212, 212, 213]],
    
           [[212, 212, 213],
            [212, 212, 213],
            [212, 212, 213],
            ...,
            [255, 255, 255],
            [255, 255, 255],
            [212, 212, 213]],
    
           [[212, 212, 213],
            [212, 212, 213],
            [212, 212, 213],
            ...,
            [255, 255, 255],
            [255, 255, 255],
            [212, 212, 213]]], dtype=uint8)




```python
palabras = data.review_body.str.cat(sep=' ')

wordcloud = WordCloud(width=800, height=400,
                     max_font_size=150, max_words=250,
                     background_color='white', colormap='copper_r',
                     stopwords=stopwords,
                     mask=mask, contour_width=0.5, contour_color='orange').generate(palabras) # https://matplotlib.org/3.1.0/tutorials/colors/colormaps.html

wordcloud.to_file("videoju.png")

plt.figure(figsize=(10,8))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis("off")
plt.tight_layout(pad=0)
plt.show()
```


![png](output_7_0.png)

